const socket = io();
let myId = null;
let username = null;
let currentRecipient = null;

const loginForm = document.getElementById("login-form");
const chatDiv = document.getElementById("chat");
const loginDiv = document.getElementById("login");
const usersList = document.getElementById("usersList");

loginForm.addEventListener("submit", e => {
  e.preventDefault();
  username = document.getElementById("username").value;
  socket.emit("register", username);
  loginDiv.style.display = "none";
  chatDiv.style.display = "block";
});

const form = document.getElementById("send-container");
const messageInput = document.getElementById("messageInp");
const messageContainer = document.querySelector(".container");

const append = (message, position) => {
  const el = document.createElement("div");
  el.innerText = message;
  el.classList.add("message", position);
  messageContainer.append(el);
  messageContainer.scrollTop = messageContainer.scrollHeight;
};

// --- Receive my ID ---
socket.on("registered", shortId => {
  myId = shortId;
  document.getElementById("myId").innerText = shortId;
  document.getElementById("myName").innerText = `You are registered as "${username}"`;
  append(`Welcome ${username}!`, "center");
});



// --- Update online users list ---
socket.on("update-users", users => {
  usersList.innerHTML = "";
  Object.entries(users).forEach(([id, info]) => {
    if (info.shortId !== myId) {
      const li = document.createElement("li");
      li.innerText = `${info.username} (${info.shortId})`;
      li.onclick = () => {
        currentRecipient = id; // still need real socket id to send message
        append(`You selected ${info.username} for private chat`, "center");
      };
      usersList.appendChild(li);
    }
  });
});


// --- Private messaging ---
socket.on("private-message", data => {
  append(`From ${data.username}: ${data.message}`, "left");
});

form.addEventListener("submit", e => {
  e.preventDefault();
  if (!currentRecipient) {
    alert("Select a user from the sidebar first!");
    return;
  }
  const message = messageInput.value;
  socket.emit("private-message", { to: currentRecipient, message });
  append(`You (to ${currentRecipient.substring(0,5)}...): ${message}`, "right");
  messageInput.value = "";
});
