const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);   // ✅ io is defined here

// serve static files from public/
app.use(express.static(path.join(__dirname, "public")));

const users = {}; // { socket.id: { username, shortId } }

io.on("connection", socket => {
  console.log("A user connected:", socket.id);

  socket.on("register", username => {
    const shortId = socket.id.substring(0, 6); // short ID
    users[socket.id] = { username, shortId };

    // send shortId back to client
    socket.emit("registered", shortId);

    // update users for everyone
    const formattedUsers = {};
    for (let [id, info] of Object.entries(users)) {
      formattedUsers[id] = { username: info.username, shortId: info.shortId };
    }
    io.emit("update-users", formattedUsers);
  });

  socket.on("private-message", data => {
    const recipient = data.to;
    io.to(recipient).emit("private-message", {
      message: data.message,
      username: users[socket.id].username
    });
  });

  socket.on("disconnect", () => {
    delete users[socket.id];
    const formattedUsers = {};
    for (let [id, info] of Object.entries(users)) {
      formattedUsers[id] = { username: info.username, shortId: info.shortId };
    }
    io.emit("update-users", formattedUsers);
  });
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
